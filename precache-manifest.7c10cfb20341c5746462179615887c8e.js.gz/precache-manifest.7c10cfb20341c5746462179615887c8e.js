self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "69d66effa0658798690853b0d0283274",
    "url": "/index.html"
  },
  {
    "revision": "bec920dfea16ad8c14fe",
    "url": "/static/css/2.bc5b1d8a.chunk.css"
  },
  {
    "revision": "ca94c134f8fc35bb39bc",
    "url": "/static/css/main.0fdf0e84.chunk.css"
  },
  {
    "revision": "bec920dfea16ad8c14fe",
    "url": "/static/js/2.98aadec9.chunk.js"
  },
  {
    "revision": "ca94c134f8fc35bb39bc",
    "url": "/static/js/main.df345a53.chunk.js"
  },
  {
    "revision": "a9bc34c64233edaba836",
    "url": "/static/js/runtime-main.37dd6726.js"
  },
  {
    "revision": "86f95a8e5c5532acae8666e4878105b5",
    "url": "/static/media/award.86f95a8e.png"
  },
  {
    "revision": "66afdc64e04580694d07af77984fbc2f",
    "url": "/static/media/depthAll.66afdc64.svg"
  },
  {
    "revision": "efcbc04e67ec7eccf3965ed2636fd4cd",
    "url": "/static/media/depthBuy.efcbc04e.svg"
  },
  {
    "revision": "58406931cb536ebc2e5c57db7e821a12",
    "url": "/static/media/depthSell.58406931.svg"
  },
  {
    "revision": "6266a393d133b7e2592118ef3e4e99ac",
    "url": "/static/media/wedexLogo.6266a393.svg"
  },
  {
    "revision": "d319b12fb327de70a1c7877cc25a2e35",
    "url": "/static/media/wedexLogoVertical.d319b12f.png"
  }
]);