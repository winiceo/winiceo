self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "3c740f01ac9c12f69b6b6681ef8ce53c",
    "url": "/index.html"
  },
  {
    "revision": "1deef25171c3c04e76a5",
    "url": "/static/css/2.8845bbd2.chunk.css"
  },
  {
    "revision": "332c289d7abc88d4e541",
    "url": "/static/css/main.bd72e6b2.chunk.css"
  },
  {
    "revision": "1deef25171c3c04e76a5",
    "url": "/static/js/2.628ac368.chunk.js"
  },
  {
    "revision": "332c289d7abc88d4e541",
    "url": "/static/js/main.cdad48db.chunk.js"
  },
  {
    "revision": "a9bc34c64233edaba836",
    "url": "/static/js/runtime-main.37dd6726.js"
  },
  {
    "revision": "86f95a8e5c5532acae8666e4878105b5",
    "url": "/static/media/award.86f95a8e.png"
  },
  {
    "revision": "66afdc64e04580694d07af77984fbc2f",
    "url": "/static/media/depthAll.66afdc64.svg"
  },
  {
    "revision": "efcbc04e67ec7eccf3965ed2636fd4cd",
    "url": "/static/media/depthBuy.efcbc04e.svg"
  },
  {
    "revision": "58406931cb536ebc2e5c57db7e821a12",
    "url": "/static/media/depthSell.58406931.svg"
  },
  {
    "revision": "5f4ffc050edf81d162af737e2af74f27",
    "url": "/static/media/fullscreen.5f4ffc05.svg"
  },
  {
    "revision": "6266a393d133b7e2592118ef3e4e99ac",
    "url": "/static/media/wedexLogo.6266a393.svg"
  },
  {
    "revision": "d319b12fb327de70a1c7877cc25a2e35",
    "url": "/static/media/wedexLogoVertical.d319b12f.png"
  }
]);